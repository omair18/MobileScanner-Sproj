package org.boofcv.android.detect;

import android.app.Activity;
import android.os.Bundle;

/**
 * Fits different shapes to black blobs found in the image
 *
 * @author Peter Abeles
 */
public class ShapeFitDisplayActivity extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}
}